class student{
    constructor(name, surname, id)
    {
        this.name = name
        this.surname = surname
        this.id = id
    }
}

export {student}