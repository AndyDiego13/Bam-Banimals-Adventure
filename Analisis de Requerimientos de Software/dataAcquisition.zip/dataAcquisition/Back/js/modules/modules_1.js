import {student} from './student.js'

let student_1 = new student("Octavio", "Navarro", "1")

console.log(student_1)